<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('movement_products', function (Blueprint $table) {
            if (!Schema::hasColumn('movement_products', 'unit_price')) {
                $table->decimal('unit_price', 15, 2)->default(0)->after('qty');
            }
        });
    }

    public function down(): void
    {
        Schema::table('movement_products', function (Blueprint $table) {
            $table->dropColumn('unit_price');
        });
    }
};